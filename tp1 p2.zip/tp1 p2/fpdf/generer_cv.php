<?php
require('fpdf.php');

$nom = $_POST['nom'] ?? '';
$prenom = $_POST['prenom'] ?? '';
$age = $_POST['age'] ?? '';
$telephone = $_POST['telephone'] ?? '';
$email = $_POST['email'] ?? '';
$photo_tmp = $_FILES['photo']['tmp_name'] ?? '';
$photo_name = $_FILES['photo']['name'] ?? '';

$stages = $_POST['stages'] ?? '';
$formations = $_POST['formations'] ?? '';
$competences = $_POST['competences'] ?? '';
$langues = $_POST['langues'] ?? '';                    
$centres_interets = $_POST['centres_interets'] ?? '';
             
if (!$photo_tmp || !$photo_name) {
    die("Erreur : Aucune photo téléchargée.");
}

$target_dir = "uploads/";

if (!is_dir($target_dir)) {
    die("Erreur : Le répertoire de destination n'existe pas.");
}

$target_file = $target_dir . basename($photo_name);

if (!move_uploaded_file($photo_tmp, $target_file)) {
    die("Erreur lors du déplacement du fichier téléchargé.");
}

$pdf = new FPDF();
$pdf->AddPage();

if (file_exists($target_file)) {
    $pdf->Image($target_file, 10, 10, 40, 40); 
}

$textWidth = $pdf->GetStringWidth("$nom $prenom");

$textX = (80 - $textWidth) / 2;
$textY = 24; 

$pdf->SetXY($textX, $textY); 
$pdf->SetFont('Arial','B',14); 
$pdf->SetTextColor(0, 0, 128); 
$pdf->Cell($textWidth, 10, "$nom $prenom", 0, 1, 'C'); 
$pdf->SetTextColor(0); 

$pdf->Ln(20);

function addSection($pdf, $title, $content) {
    $pdf->SetFont('Arial','B',12);
    $pdf->SetTextColor(0, 0, 128); 
    $pdf->Cell(0,10,$title,0,1,'L');
    $titleWidth = $pdf->GetStringWidth($title);
    $pdf->SetLineWidth(0.5);
    $pdf->SetDrawColor(0, 0, 128); 
    $pdf->Line(10, $pdf->GetY(), 10 + $titleWidth, $pdf->GetY()); 
    $pdf->SetFont('Arial','',12);
    $pdf->SetTextColor(0); 
    $pdf->MultiCell(0,8,$content); 
}

addSection($pdf, 'Informations personnelles : ', "Nom: $nom\nPrénom: $prenom\nÂge: $age\nTéléphone: $telephone\nEmail: $email");
addSection($pdf, 'Stages : ', $stages);
addSection($pdf, 'Formations : ', $formations);
addSection($pdf, 'Compétences : ', $competences);
addSection($pdf, 'Langues : ', $langues);
addSection($pdf, 'Centres d\'intérêts : ', $centres_interets);

$pdf->Output('F', 'cv.pdf');

header('Location: cv.pdf');
exit;   
?>
                                                              