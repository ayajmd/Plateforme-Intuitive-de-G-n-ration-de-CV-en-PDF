﻿<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Formulaire de CV</title>
<style>
  body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
  }

  form {
    background-color: #fff;
    max-width: 600px;
    margin: 20px auto;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  }

  h1 {
    text-align: center;
    margin-bottom: 20px;
  }

  label {
    display: block;
    margin-bottom: 5px;
    font-weight: bold;
  }

  input[type="text"],
  input[type="email"],
  input[type="file"],
  textarea {
    width: calc(100% - 10px);
    margin-bottom: 10px;
    padding: 8px;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
  }

  input[type="submit"] {
    width: 100%;
    background-color: #007bff;
    color: #fff;
    padding: 10px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    transition: background-color 0.3s ease;
  }

  input[type="submit"]:hover {
    background-color: #0056b3;
  }
</style>
</head>
<body>

<h1>Votre CV</h1>

<form action="generer_cv.php" method="post" enctype="multipart/form-data">
  <label for="nom">Nom:</label>
  <input type="text" id="nom" name="nom" required>

  <label for="prenom">Prénom:</label>
  <input type="text" id="prenom" name="prenom" required>

  <label for="age">Âge:</label>
  <input type="text" id="age" name="age" required>

  <label for="telephone">Téléphone:</label>
  <input type="text" id="telephone" name="telephone" required>

  <label for="email">Email:</label>
  <input type="email" id="email" name="email" required>

  <label for="photo">Photo:</label>
  <input type="file" id="photo" name="photo" accept="image/*" required>

  <label for="stages">Stages:</label>
  <textarea id="stages" name="stages" rows="4" required></textarea>

  <label for="formations">Formations:</label>
  <textarea id="formations" name="formations" rows="4" required></textarea>

  <label for="competences">Compétences:</label>
  <textarea id="competences" name="competences" rows="4" required></textarea>

  <label for="langues">Langues:</label>
  <textarea id="langues" name="langues" rows="4" required></textarea>

  <label for="centres_interets">Centres d'intérêts:</label>
  <textarea id="centres_interets" name="centres_interets" rows="4" required></textarea>

  <input type="submit" value="Générer CV">
</form>

</body>
</html>
